/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import conexion.ConexionBD;
/**
 *
 * @author khale
 */
public class TestConexion {
    public static void main(String[] args) {
        if (ConexionBD.conectar() != null) {
            System.out.println("Conexión exitosa");
        } else {
            System.out.println("Fallo la conexión");
        }
    }
}
