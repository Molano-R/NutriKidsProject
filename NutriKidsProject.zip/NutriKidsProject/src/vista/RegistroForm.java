/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import modelo.Usuario;
import modelo.UsuarioDAO;

import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class RegistroForm extends JFrame {
    private JTextField txtNombre, txtCorreo;
    private JPasswordField txtContrasena, txtClaveAdmin;
    private JComboBox<String> comboRol;
    private JButton btnRegistrar;

    private static final String CLAVE_ADMIN = "admin123"; // Clave secreta

    public RegistroForm() {
        setTitle("Registro de Usuario");
        setSize(300, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lbl1 = new JLabel("Nombre:");
        lbl1.setBounds(20, 20, 80, 25);
        add(lbl1);

        txtNombre = new JTextField();
        txtNombre.setBounds(100, 20, 150, 25);
        add(txtNombre);

        JLabel lbl2 = new JLabel("Correo:");
        lbl2.setBounds(20, 60, 80, 25);
        add(lbl2);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(100, 60, 150, 25);
        add(txtCorreo);

        JLabel lbl3 = new JLabel("Contraseña:");
        lbl3.setBounds(20, 100, 80, 25);
        add(lbl3);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(100, 100, 150, 25);
        add(txtContrasena);

        JLabel lbl4 = new JLabel("Rol:");
        lbl4.setBounds(20, 140, 80, 25);
        add(lbl4);

        comboRol = new JComboBox<>(new String[]{"Padre", "Madre", "Administrador"});
        comboRol.setBounds(100, 140, 150, 25);
        add(comboRol);

        JLabel lblClaveAdmin = new JLabel("Clave Admin:");
        lblClaveAdmin.setBounds(20, 180, 100, 25);
        add(lblClaveAdmin);

        txtClaveAdmin = new JPasswordField();
        txtClaveAdmin.setBounds(120, 180, 130, 25);
        txtClaveAdmin.setEnabled(false); // por defecto desactivado
        add(txtClaveAdmin);

        comboRol.addActionListener(e -> {
            String rolSeleccionado = (String) comboRol.getSelectedItem();
            boolean esAdmin = rolSeleccionado.equals("Administrador");
            txtClaveAdmin.setEnabled(esAdmin);
        });

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(90, 230, 100, 30);
        add(btnRegistrar);

        btnRegistrar.addActionListener(e -> {
            String rol = (String) comboRol.getSelectedItem();

            if (rol.equals("Administrador")) {
                String claveIngresada = new String(txtClaveAdmin.getPassword());
                if (!CLAVE_ADMIN.equals(claveIngresada)) {
                    JOptionPane.showMessageDialog(this, "Clave de administrador incorrecta.");
                    return;
                }
            }

            Usuario u = new Usuario();
            u.setNombre(txtNombre.getText());
            u.setCorreo(txtCorreo.getText());
            u.setContrasena(new String(txtContrasena.getPassword()));
            u.setRol(rol);

            UsuarioDAO dao = new UsuarioDAO();
            if (dao.registrar(u)) {
                JOptionPane.showMessageDialog(this, "Usuario registrado con éxito");
                new Login().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar");
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
