/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import modelo.Consejo;
import modelo.ConsejosManager;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

public class ConsejosUI extends JFrame {
    private JLabel lblConsejo;
    private JButton btnNuevo, btnFavorito;
    private Consejo consejoActual;
    private ConsejosManager consejosManager;
    private int idUsuario;
    private Set<Integer> favoritosGuardados = new HashSet<>();

    public ConsejosUI(Connection conn, int idUsuario) {
        this.consejosManager = new ConsejosManager(conn);
        this.idUsuario = idUsuario;

        setTitle("Consejo del Día");
        setLayout(new BorderLayout());
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Mejor que EXIT para volver al menú

        // Etiqueta para mostrar el consejo
        lblConsejo = new JLabel("Cargando consejo...", SwingConstants.CENTER);
        lblConsejo.setFont(new Font("Arial", Font.PLAIN, 14));
        add(lblConsejo, BorderLayout.CENTER);

        // Panel inferior con botones
        JPanel panelBotones = new JPanel();
        btnNuevo = new JButton("Otro Consejo");
        btnFavorito = new JButton("Guardar como Favorito");
        panelBotones.add(btnNuevo);
        panelBotones.add(btnFavorito);
        add(panelBotones, BorderLayout.SOUTH);

        // Acciones de botones
        btnNuevo.addActionListener(e -> mostrarConsejo());
        btnFavorito.addActionListener(e -> guardarFavorito());

        // Mostrar primer consejo
        mostrarConsejo();
        setVisible(true);
    }

    private void mostrarConsejo() {
        try {
            consejoActual = consejosManager.obtenerConsejoAleatorio();
            if (consejoActual != null) {
                lblConsejo.setText("<html><div style='text-align:center;'>" + consejoActual.getTexto() + "</div></html>");

                // Habilitar botón si el consejo aún no fue guardado
                boolean yaGuardado = favoritosGuardados.contains(consejoActual.getId());
                btnFavorito.setEnabled(!yaGuardado);
            } else {
                lblConsejo.setText("No hay consejos disponibles.");
                btnFavorito.setEnabled(false);
            }
        } catch (SQLException e) {
            lblConsejo.setText("Error al cargar consejo.");
            btnFavorito.setEnabled(false);
            e.printStackTrace();
        }
    }

    private void guardarFavorito() {
        if (consejoActual == null) {
            JOptionPane.showMessageDialog(this, "No hay consejo para guardar.");
            return;
        }

        if (favoritosGuardados.contains(consejoActual.getId())) {
            JOptionPane.showMessageDialog(this, "Este consejo ya está en tus favoritos.");
            return;
        }

        try {
            boolean exito = consejosManager.guardarFavorito(idUsuario, consejoActual.getId());
            if (exito) {
                favoritosGuardados.add(consejoActual.getId());
                btnFavorito.setEnabled(false); // Deshabilitar después de guardar
                JOptionPane.showMessageDialog(this, "Consejo guardado como favorito.");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el consejo.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar consejo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
