/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import modelo.Usuario;
import modelo.Nino;
import modelo.NinoDAO;
import javax.swing.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class RegistroNinoForm extends JFrame {
    private JTextField txtNombre, txtEdad, txtPeso, txtAltura;
    private JButton btnRegistrar;
    private Usuario usuario;

    public RegistroNinoForm(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Registro de Hijo/a");
        setSize(350, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl1 = new JLabel("Nombre:");
        lbl1.setBounds(20, 20, 100, 25);
        add(lbl1);

        txtNombre = new JTextField();
        txtNombre.setBounds(130, 20, 150, 25);
        add(txtNombre);

        JLabel lbl2 = new JLabel("Edad (meses):");
        lbl2.setBounds(20, 60, 100, 25);
        add(lbl2);

        txtEdad = new JTextField();
        txtEdad.setBounds(130, 60, 150, 25);
        add(txtEdad);

        JLabel lbl3 = new JLabel("Peso (kg):");
        lbl3.setBounds(20, 100, 100, 25);
        add(lbl3);

        txtPeso = new JTextField();
        txtPeso.setBounds(130, 100, 150, 25);
        add(txtPeso);

        JLabel lbl4 = new JLabel("Altura (cm):");
        lbl4.setBounds(20, 140, 100, 25);
        add(lbl4);

        txtAltura = new JTextField();
        txtAltura.setBounds(130, 140, 150, 25);
        add(txtAltura);

        btnRegistrar = new JButton("Registrar Hijo/a");
        btnRegistrar.setBounds(90, 200, 160, 30);
        add(btnRegistrar);

        btnRegistrar.addActionListener(e -> {
            try {
                Nino n = new Nino();
                n.setUsuarioId(usuario.getId()); // Obtenemos el ID del usuario desde el objeto
                n.setNombre(txtNombre.getText());
                n.setEdadMeses(Integer.parseInt(txtEdad.getText()));
                n.setPeso(Double.parseDouble(txtPeso.getText()));
                n.setAltura(Double.parseDouble(txtAltura.getText()));

                NinoDAO dao = new NinoDAO();
                if (dao.registrar(n)) {
                    JOptionPane.showMessageDialog(this, "Registro exitoso");
                    dispose(); // Cierra la ventana tras registro
                } else {
                    JOptionPane.showMessageDialog(this, "Error al registrar");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos: " + ex.getMessage());
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
