/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import modelo.Usuario;
import modelo.Guia;
import modelo.GuiaDAO;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class GuiaAlimentacionForm extends JFrame {
    private JComboBox<String> comboCategoria;
    private JTextArea areaContenido;
    private JButton btnBuscar;
    private Usuario usuario;

    public GuiaAlimentacionForm(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Guías de Alimentación");
        setSize(1000, 700);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        comboCategoria = new JComboBox<>(new String[]{"bebés", "niños pequeños", "preescolares"});
        btnBuscar = new JButton("Buscar Guías");
        topPanel.add(comboCategoria);
        topPanel.add(btnBuscar);
        add(topPanel, BorderLayout.NORTH);

        areaContenido = new JTextArea();
        areaContenido.setEditable(false);
        add(new JScrollPane(areaContenido), BorderLayout.CENTER);

        btnBuscar.addActionListener(e -> {
            String categoria = (String) comboCategoria.getSelectedItem();
            GuiaDAO dao = new GuiaDAO();
            List<Guia> guias = dao.obtenerGuiasPorCategoria(categoria);
            areaContenido.setText("");
            for (Guia g : guias) {
                areaContenido.append("- " + g.getContenido() + "\n\n");
            }
        });

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
