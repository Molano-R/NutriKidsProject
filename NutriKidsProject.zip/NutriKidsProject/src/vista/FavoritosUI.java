/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import modelo.Consejo;
import modelo.ConsejosFavoritosManager;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.List;

public class FavoritosUI extends JFrame {
    public FavoritosUI(Connection conn, int idUsuario) {
        setTitle("Mis Consejos Favoritos");
        setSize(400, 300);
        setLayout(new BorderLayout());

        JTextArea area = new JTextArea();
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);
        add(scroll, BorderLayout.CENTER);

        ConsejosFavoritosManager manager = new ConsejosFavoritosManager(conn);
        try {
            List<Consejo> favoritos = manager.obtenerFavoritos(idUsuario);
            StringBuilder sb = new StringBuilder();
            for (Consejo c : favoritos) {
                sb.append("• ").append(c.getTexto()).append("\n\n");
            }
            area.setText(sb.toString());
        } catch (SQLException e) {
            area.setText("Error al cargar favoritos.");
        }

        setVisible(true);
    }
}
