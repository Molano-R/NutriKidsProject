/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */


import modelo.Usuario;
import modelo.UsuarioDAO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnLogin, btnRegistro;
    private JComboBox<String> comboRol;

    public Login() {
        setTitle("Login NutriKids");
        setSize(350, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblUsuario = new JLabel("Correo:");
        lblUsuario.setBounds(30, 30, 80, 25);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(120, 30, 180, 25);
        add(txtUsuario);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setBounds(30, 70, 80, 25);
        add(lblContrasena);

        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(120, 70, 180, 25);
        add(txtContrasena);

        JLabel lblRol = new JLabel("Rol:");
        lblRol.setBounds(30, 110, 80, 25);
        add(lblRol);

        comboRol = new JComboBox<>(new String[]{"Padre", "Madre", "Administrador"});
        comboRol.setBounds(120, 110, 180, 25);
        add(comboRol);

        btnLogin = new JButton("Iniciar sesión");
        btnLogin.setBounds(50, 160, 120, 30);
        add(btnLogin);

        btnRegistro = new JButton("Registrarse");
        btnRegistro.setBounds(180, 160, 120, 30);
        add(btnRegistro);

        // Acción para iniciar sesión
        btnLogin.addActionListener(e -> {
            String usuarioInput = txtUsuario.getText();
            String contrasenaInput = new String(txtContrasena.getPassword());
            String rolSeleccionado = (String) comboRol.getSelectedItem();

            UsuarioDAO usuarioDAO = new UsuarioDAO();
            Usuario usuario = usuarioDAO.validarUsuario(usuarioInput, contrasenaInput, rolSeleccionado);

            if (usuario != null) {
                JOptionPane.showMessageDialog(null, "Bienvenido " + usuario.getNombre());
                MenuPrincipal menu = new MenuPrincipal(usuario);
                menu.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Credenciales o rol incorrecto.");
            }
        });

        // Acción para abrir formulario de registro
        btnRegistro.addActionListener(e -> {
            RegistroForm registro = new RegistroForm();
            registro.setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Login login = new Login();
            login.setVisible(true);
        });
    }
}