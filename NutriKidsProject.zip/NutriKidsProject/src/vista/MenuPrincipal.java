/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author khale
 */
import conexion.ConexionBD;
import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class MenuPrincipal extends JFrame {
    private Usuario usuario;

    public MenuPrincipal(Usuario usuario) {
        this.usuario = usuario;
        setTitle("Menú Principal - NutriKids");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(0, 1, 10, 10));

        JButton btnRegistroNino = new JButton("Registrar/Actualizar información de hijo/a");
        JButton btnGuiaAlimentacion = new JButton("Ver guías de alimentación");
        JButton btnConsejos = new JButton("Consejos diarios y hábitos saludables");
        JButton btnFavoritos = new JButton("Ver consejos favoritos");
        JButton btnNotificaciones = new JButton("Notificaciones y recordatorios");
        JButton btnAsignarRoles = new JButton("Asignar roles a usuarios");

        add(btnRegistroNino);
        add(btnGuiaAlimentacion);
        add(btnConsejos);
        add(btnFavoritos);
        add(btnNotificaciones);

        if (usuario.getRol().equalsIgnoreCase("administrador")) {
            add(btnAsignarRoles);
        }

        btnRegistroNino.addActionListener(e -> {
            try {
                RegistroNinoForm registro = new RegistroNinoForm(usuario);
                registro.setVisible(true);
                
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al abrir la vista: " + ex.getMessage());
            }
        });

        btnGuiaAlimentacion.addActionListener(e -> {
            try {
                GuiaAlimentacionForm guia = new GuiaAlimentacionForm(usuario);
                guia.setVisible(true);
                
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al abrir la vista: " + ex.getMessage());
            }
        });

        // 👉 Consejos diarios
        btnConsejos.addActionListener(e -> {
            Connection conn = ConexionBD.conectar();
            if (conn != null) {
                ConsejosUI consejosUI = new ConsejosUI(conn, usuario.getId());
                consejosUI.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            }
        });

        // ⭐ Favoritos
        btnFavoritos.addActionListener(e -> {
            Connection conn = ConexionBD.conectar();
            if (conn != null) {
                FavoritosUI favoritosUI = new FavoritosUI(conn, usuario.getId());
                favoritosUI.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos.");
            }
        });

        btnNotificaciones.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Notificaciones y recordatorios en desarrollo.");
        });

        btnAsignarRoles.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Asignación de roles en desarrollo.");
        });
    }
}
