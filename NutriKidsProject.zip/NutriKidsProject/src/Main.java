/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khale
 */
import conexion.ConexionBD;
import java.sql.Connection;
import javax.swing.SwingUtilities;
import vista.Login;

public class Main {
    public static void main(String[] args) {
        Connection con = ConexionBD.conectar();

        if (con != null) {
            System.out.println("✅ Conexión a la base de datos establecida correctamente.");

            // Iniciar interfaz gráfica en el hilo de eventos de Swing
            SwingUtilities.invokeLater(() -> {
                Login login = new Login();
                login.setVisible(true);
            });

        } else {
            System.out.println("❌ No se pudo conectar a la base de datos.");
        }
    }
}
