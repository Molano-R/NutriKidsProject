/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author khale
 */
import java.sql.*;

public class ConsejosManager {
    private Connection conn;

    public ConsejosManager(Connection conn) {
        this.conn = conn;
    }

    public Consejo obtenerConsejoAleatorio() throws SQLException {
        String sql = "SELECT * FROM consejos ORDER BY RAND() LIMIT 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return new Consejo(rs.getInt("id"), rs.getString("contenido"));
            }
        }
        return null;
    }

    public boolean guardarFavorito(int idUsuario, int idConsejo) throws SQLException {
        // Verificar si ya está guardado antes de intentar insertar
        if (yaEsFavorito(idUsuario, idConsejo)) {
            return false;
        }

        String sql = "INSERT INTO consejos_favoritos (id_usuario, id_consejo) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idUsuario);
            pstmt.setInt(2, idConsejo);
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean yaEsFavorito(int idUsuario, int idConsejo) throws SQLException {
        String sql = "SELECT 1 FROM consejos_favoritos WHERE id_usuario = ? AND id_consejo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idUsuario);
            pstmt.setInt(2, idConsejo);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
}
