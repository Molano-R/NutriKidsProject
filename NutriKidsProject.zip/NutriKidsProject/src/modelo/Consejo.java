/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author khale
 */
public class Consejo {
    private int id;
    private String contenido;

    public Consejo(int id, String contenido) {
        this.id = id;
        this.contenido = contenido;
    }

    public int getId() { return id; }
    public String getTexto() { return contenido; }  // mantén getTexto() si tu UI lo usa
    public String toString() { return contenido; }
}
