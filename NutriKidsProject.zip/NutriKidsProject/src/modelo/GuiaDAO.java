/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author khale
 */
import conexion.ConexionBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GuiaDAO {
    public List<Guia> obtenerGuiasPorCategoria(String categoria) {
        List<Guia> guias = new ArrayList<>();
        String sql = "SELECT * FROM guias WHERE categoria = ?";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, categoria);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Guia g = new Guia();
                g.setId(rs.getInt("id"));
                g.setCategoria(rs.getString("categoria"));
                g.setContenido(rs.getString("contenido"));
                guias.add(g);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener guías: " + e.getMessage());
        }
        return guias;
    }
}
