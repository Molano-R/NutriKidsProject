/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author khale
 */

import java.sql.*;
import java.util.*;

public class ConsejosFavoritosManager {
    private Connection conn;

    public ConsejosFavoritosManager(Connection conn) {
        this.conn = conn;
    }

    public List<Consejo> obtenerFavoritos(int idUsuario) throws SQLException {
        List<Consejo> lista = new ArrayList<>();

        String sql = "SELECT c.id, c.contenido " +
                     "FROM consejos_favoritos cf " +
                     "JOIN consejos c ON cf.id_consejo = c.id " +
                     "WHERE cf.id_usuario = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idUsuario);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String contenido = rs.getString("contenido");
                    lista.add(new Consejo(id, contenido));
                }
            }
        }

        return lista;
    }
}
