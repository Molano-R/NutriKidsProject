/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author khale
 */
import conexion.ConexionBD;
import java.sql.*;

public class NinoDAO {
    public boolean registrar(Nino n) {
        String sql = "INSERT INTO ninos(usuario_id, nombre, edad_meses, peso, altura) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, n.getUsuarioId());
            ps.setString(2, n.getNombre());
            ps.setInt(3, n.getEdadMeses());
            ps.setDouble(4, n.getPeso());
            ps.setDouble(5, n.getAltura());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al registrar niño: " + e.getMessage());
            return false;
        }
    }
}
